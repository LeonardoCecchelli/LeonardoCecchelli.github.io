import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class Parser
{
    public static void main(String args[])
    {
        try
        {
            File fileJB=new File(args[0]);    //creates a new file instance
            FileReader fr=new FileReader(fileJB);   //reads the file
            BufferedReader br=new BufferedReader(fr);  //creates a buffering character input stream */
            File fileSMV=new File("BytecodeNuSMV.smv");
            FileWriter fw=new FileWriter(fileSMV);

            String line;
            String smvModel="";
            File fileSMV1=new File("smvBody/smvPART1.txt");
            FileReader frSMV1=new FileReader(fileSMV1);
            BufferedReader brSMV1=new BufferedReader(frSMV1);
            while((line=brSMV1.readLine())!=null)
            {
                smvModel=smvModel.concat(line+"\n");
            }

            ArrayList<String[]> instructions=new ArrayList<>();
            while((line=br.readLine())!=null)
            {
                String[] parts = line.split(" ");
                instructions.add(parts);
            }
            int i=0;
            for(String[] s:instructions)
            {
                smvModel=smvModel.concat("\t\tinit(program_instructions["+i+"]) := "+s[0]+";\n");
                i++;
            }
            for(;i<10;i++){
                smvModel=smvModel.concat("\t\tinit(program_instructions["+i+"]) := halt;\n");
            }
            smvModel=smvModel.concat("\n-- For each instruction we specify the variable used for that instruction (-1 no parameters)\n");
            i=0;
            for(String[] s:instructions)
            {
                smvModel=smvModel.concat("\t\tinit(instructions_parameters["+i+"]) := "+s[1]+";\n");
                i++;
            }
            for(;i<10;i++){
                smvModel=smvModel.concat("\t\tinit(instructions_parameters["+i+"]) := -1;\n");
            }
            File fileSMV2=new File("smvBody/smvPART2.txt");
            FileReader frSMV2=new FileReader(fileSMV2);
            BufferedReader brSMV2=new BufferedReader(frSMV2);
            while((line=brSMV2.readLine())!=null)
            {
                smvModel=smvModel.concat(line+"\n");
            }
            fw.append(smvModel);
            fr.close();
            fw.close();
        }
        catch(IOException e) {
            e.printStackTrace();
        }
    }
}  