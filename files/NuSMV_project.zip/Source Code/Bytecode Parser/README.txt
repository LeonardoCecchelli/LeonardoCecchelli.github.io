Execution steps:

1) Compile the Parser.java file
2) Execute the Parser.class file specifying a txt document as input
   Example: java Parser.class program.txt
3) The parser will generate a .smv file that can be simulated with NuSMV