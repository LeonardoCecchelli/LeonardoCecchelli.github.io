BytecodeNuSMV.smv is ready to be simulated in NuSMV.

The structure of the program that is going to be analyzed is the following one:

if(x==0)
    y=x;
z=y;

which results in the following Bytecode translation:

load    0;
ipd     5;
if      5;
load    0;
store   1;
load    1;
store   2;
halt   -1; 