<?php
	require_once "./../utility/eventcrate_db_connections.php";
    require_once "./../utility/eventcrate_db_session.php";
	
	$username = $_POST['username'];
	$email = $_POST['email'];
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$birthdate = $_POST['birthdate'];
	$region = $_POST['regions'];
	$city = $_POST['city'];
	$password = $_POST['password'];
	
	$errorMessage = register($username, $email, $firstname, $lastname, $birthdate, $region, $city, $password);
	if($errorMessage === 'Registrazione effettuata con successo')
		header('location: ./../../index.php?errorMessage' . $errorMessage);
	else
		header('location: ./../registration.php?errorMessage=' . $errorMessage );
	
	function register($username,$email,$firstname,$lastname,$birthdate,$region,$city,$password){
		global $EventCrateDb;
		if ($username == NULL || $email == NULL || $firstname == NULL || $lastname == NULL || $password == NULL) { //dati non inseriti
			return 'Errore: uno o piu campi non sono stati inseriti';
		}
		else {
			$queryText = "select * from dati_registrazione where username='" . $username . "'";
			$result = $EventCrateDb->performQuery($queryText);
			$numRow = mysqli_num_rows($result);
			if ($numRow == 1) { //username gi� presente
				return 'Username gia utilizzato';
			}
			$queryText = "select * from dati_registrazione where email='" . $email . "'";
			$result = $EventCrateDb->performQuery($queryText);
			$numRow = mysqli_num_rows($result);
			if ($numRow == 1) { //email gi� presente
				return 'Email gia utilizzata';
			}
			else { //dati consistenti
				$queryText = "insert into dati_registrazione values('" . $username . "', '" . $email . "', '" . $firstname . "', '" . $lastname . "', '" . $birthdate . "', '" . $region . "', '" . $city . "', '" . $password . "')";
				$result = $EventCrateDb->performQuery($queryText);
				return 'Registrazione effettuata con successo';
			}
		}
	}
?>