<?php
	session_start();
	require_once "./../utility/eventcrate_db_connections.php";
	require_once "./../utility/eventcrate_db_session.php";

	$title = $_POST['title'];
	$description = $_POST['description'];
	$category = $_POST['category'];
	$region = $_POST['regions'];
	$city = $_POST['city'];
	$address = $_POST['address'];
	$date = $_POST['date'];
	$time = $_POST['time'];
	$private = $_POST['private'];

	$image = file_get_contents($_FILES["image"]["tmp_name"]);

	$creator = $_SESSION['username'];


	$errorMessage = upload($title, $description, $category, $region, $city, $address, $date, $time, $image, $private, $creator);
	if($errorMessage === 'Evento creato')
		header('location: ./../home.php?errorMessage' . $errorMessage);
	else
		header('location: ./../creationtool.php?errorMessage=' . $errorMessage );

	function upload($title, $description, $category, $region, $city, $address, $date, $time, $image, $private, $creator){
		global $EventCrateDb;
		/*script per elaborazione dell'immagine */
		$image = $EventCrateDb->sqlInjectionFilter($image);
		$image_type = $EventCrateDb->sqlInjectionFilter($_FILES["image"]["type"]);
		if (substr($image_type,0,5) != "image"){
			return "Il formato dell' immagine che hai inseito non � valido";
		}
		/* fine elaborazione immagine */
		if ($title == NULL || $description == NULL || $category == NULL || $region == NULL || $city == NULL || $address == NULL || $date == NULL || $time == NULL) { //dati non inseriti
			return 'Una o piu informazioni importanti sono assenti';
		}
		else {
			$title = $EventCrateDb->sqlInjectionFilter($title);
			$description = $EventCrateDb->sqlInjectionFilter($description);
			$category = $EventCrateDb->sqlInjectionFilter($category);
			$region = $EventCrateDb->sqlInjectionFilter($region);
			$city = $EventCrateDb->sqlInjectionFilter($city);
			$address = $EventCrateDb->sqlInjectionFilter($address);
			$date = $EventCrateDb->sqlInjectionFilter($date);
			$time = $EventCrateDb->sqlInjectionFilter($time);

			$queryText = "select * from eventi where nome_evento='" . $title . "' and categoria='" . $category . "' creatore='" . $creator . "'";
			$result = $EventCrateDb->performQuery($queryText);
			$numRow = mysqli_num_rows($result);
			if ($numRow == 1) {
				return "Hai gia' creato un evento uguale a questo";
			}
			else { //dati consistenti
				$queryText = "insert into eventi (nome_evento, creatore, categoria, data, regione, citta, via, privato, descrizione, immagine, orario) values('" . $title . "', '" . $creator . "', '" . $category . "', '" . $date . "', '" . $region . "', '" . $city . "', '" . $address . "', '" . $private . "', '" . $description . "', '" . $image . "', '" . $time . "')";
				$result = $EventCrateDb->performQuery($queryText);
				return 'Evento creato';
			}
		}
	}


?>
