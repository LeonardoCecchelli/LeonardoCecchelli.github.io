<?php
	session_start();
	require_once "./../utility/eventcrate_db_connections.php";
	require_once "./../utility/eventcrate_db_session.php";

	if (!isLogged()){
		    header('Location: ./../../sign_in.php');
		    exit;
    }
  $event_id = $_GET['eventid'];
  $username = $_SESSION['username'];

  global $EventCrateDb;

  $queryText ="select * from eventi where event_id ='" . $event_id . "' and creatore ='" . $username . "'";
  $result = $EventCrateDb->performQuery($queryText);
  $numRow = mysqli_num_rows($result);
  if ($numRow == 0) { //Non era l'owner dell'evento, cancellazione negata
    header('Location: ./../../php/eventpage.php?eventid=' . $event_id . '');
    exit;
  }

  $queryText = "delete from partecipazione where event_id ='" . $event_id . "'";
  $result = $EventCrateDb->performQuery($queryText);
  $queryText = "delete from richieste_partecipazione where event_id ='" . $event_id . "'";
  $result = $EventCrateDb->performQuery($queryText);
  $queryText = "delete from richieste_rifiutate where event_id ='" . $event_id . "'";
  $result = $EventCrateDb->performQuery($queryText);
  $queryText = "delete from eventi where event_id ='" . $event_id . "'";
  $result = $EventCrateDb->performQuery($queryText);
	header('Location: ./../../php/myevents.php');
?>
