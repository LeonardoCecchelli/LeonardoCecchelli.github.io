<?php
	session_start();
	require_once "./../utility/eventcrate_db_connections.php";
    require_once "./../utility/eventcrate_db_session.php";
	
	$username = $_SESSION['username'];
	
	$birthdate = $EventCrateDb->sqlInjectionFilter($_POST['birthdate']);
	$region = $EventCrateDb->sqlInjectionFilter($_POST['region']);
	$city = $EventCrateDb->sqlInjectionFilter($_POST['city']);
	
	$errorMessage = update($birthdate, $region, $city, $username);
	header('location: ./../profile.php?errorMessage=' . $errorMessage);
	
	function update($birthdate, $region, $city, $username){
		global $EventCrateDb;
		$queryText = "update dati_registrazione set data_nascita = '" . $birthdate . "', regione = '" . $region . "', citta = '" . $city . "' where username='" . $username . "'";
		$result = $EventCrateDb->performQuery($queryText);
		return 'Dati aggiornati con successo';
	}
	
?>