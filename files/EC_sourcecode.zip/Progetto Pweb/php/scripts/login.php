<?php
	require_once "./../utility/eventcrate_db_connections.php";
  require_once "./../utility/eventcrate_db_session.php";

	$username = $_POST['username'];
	$password = $_POST['password'];

	$errorMessage = login($username, $password);
	if($errorMessage === null){
		if(isset($_SESSION['addressto'])){
			header('location: ./../' . $_SESSION['addressto']);
			/* sara' resettato al logout */
		}
		else {
			header('location: ./../home.php');
		}
	}
	else{
		header('location: ./../sign_in.php?errorMessage=' . $errorMessage );
	}

	function login($username, $password){
		if ($username == NULL || $password == NULL){
			return 'Errore: uno o piu campi non sono stati inseriti';
		}
		else {
		$user_id = check($username, $password);
    		if ($user_id > 0){
    			session_start();
    			CreateSession($username, $user_id);
    			return null;
    		}
			else {
				return 'Username o password errati';
			}
		}
	}

	function check($username, $password){
		global $EventCrateDb;
		$username = $EventCrateDb->sqlInjectionFilter($username);
		$password = $EventCrateDb->sqlInjectionFilter($password);
		$queryText = "select * from utente where username='" . $username . "' AND password='" . $password . "'";
		$result = $EventCrateDb->performQuery($queryText);
		$numRow = mysqli_num_rows($result);
		if ($numRow != 1){
			return -1;
		}
		$EventCrateDb->closeConnection();
		$userRow = $result->fetch_assoc();
		$EventCrateDb->closeConnection();
		return $userRow['user_id'];
	}
?>
