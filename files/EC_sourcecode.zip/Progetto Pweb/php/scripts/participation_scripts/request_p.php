<?php
	session_start();
	require_once "./../../utility/eventcrate_db_connections.php";
	require_once "./../../utility/eventcrate_db_session.php";
	
	if (!isLogged()){
		    header('Location: ./../../sign_in.php');
		    exit;
    }
	
	$user_id = $_SESSION['user_id'];
	$username = $_SESSION['username'];
	$event_id = $_GET['eventid'];
	
	$queryText = "select data from eventi where event_id = '" . $event_id . "'";
	$result = $EventCrateDb->performQuery($queryText);
	$result = $result->fetch_assoc();
	$data = $result['data'];

	$queryText = "select * from partecipazione where event_id ='" . $event_id . "' and user_id ='" . $user_id . "'";
	$result = $EventCrateDb->performQuery($queryText);
	$numRow = mysqli_num_rows($result);
	if ($numRow == 1) {
		header('Location: ./../../eventpage.php?eventid=' . $event_id . '');
		exit;
	}
	$queryText = "select * from richieste_partecipazione where event_id ='" . $event_id . "' and user_id ='" . $user_id . "'";
	$result = $EventCrateDb->performQuery($queryText);
	$numRow = mysqli_num_rows($result);
	if ($numRow == 1) {
		header('Location: ./../../eventpage.php?eventid=' . $event_id . '');
		exit;
	}
	$queryText = "insert into richieste_partecipazione values('" . $event_id . "', '" . $user_id . "','" . $username . "','" . $data . "')";
	$result = $EventCrateDb->performQuery($queryText);
	header('Location: ./../../eventpage.php?eventid=' . $event_id . '');
?>