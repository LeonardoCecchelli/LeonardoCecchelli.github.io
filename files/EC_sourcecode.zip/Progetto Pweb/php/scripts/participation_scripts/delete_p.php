<?php
	session_start();
	require_once "./../../utility/eventcrate_db_connections.php";
	require_once "./../../utility/eventcrate_db_session.php";
	
	if (!isLogged()){
		    header('Location: ./../../sign_in.php');
		    exit;
    }
	
	$user_id = $_SESSION['user_id'];
	$username = $_SESSION['username'];
	$event_id = $_GET['eventid'];
	/* controllo presenza row */
	$queryText = "select * from partecipazione where event_id ='" . $event_id . "' and user_id ='" . $user_id . "'";
	$result = $EventCrateDb->performQuery($queryText);
	$numRow = mysqli_num_rows($result);
	if ($numRow == 0) {
		header('Location: ./../../eventpage.php?eventid=' . $event_id . '');
		exit;
	}
	$queryText = "delete from partecipazione where user_id ='" . $user_id . "' and event_id ='" . $event_id . "'";
	$result = $EventCrateDb->performQuery($queryText);
	header('Location: ./../../eventpage.php?eventid=' . $event_id . '');
?>