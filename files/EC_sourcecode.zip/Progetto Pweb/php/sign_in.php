<!DOCTYPE=html>
<?php
	session_start();
    include "./utility/eventcrate_db_session.php";
    if (isLogged()){
		    header('Location: ./home.php');
		    exit;
    }
?>
<html lang="it">
		<head>
		<style>
		@import url('https://fonts.googleapis.com/css?family=Fredoka+One');
		@import url('https://fonts.googleapis.com/css?family=M+PLUS+Rounded+1c');
		</style>
		<meta charset="utf-8"> 
		<meta name = "author" content = "Leonardo">
		<meta name = "keywords" content = "eventcrate, events, event planner, online planner, event manager, registration">
		<meta name = "description" content = "Crea, organizza o partecipa agli eventi direttamente tramite la nostra piattaforma online">
		<link rel="stylesheet" href="./../css/registration.css" type="text/css" media="screen">
		<script type="text/javascript" src="./../js/registration.js"></script>
		<title>EventCrate - Login</title>
	</head>
	<body>
		<div class="top_h1">
		<a href="./../index.php"><img class="back-arrow" src="./../css/img/left-arrow.png" alt="indietro"></a>
		<h1>Entra</h1>
		</div>
		<div class="registration_box">
			<div class="login_box">
				<form id="reg_form" action="./scripts/login.php" method="post">
					<?php
						if (isset($_GET['errorMessage'])){
							echo '<div class="sign_in_error">';
							echo '<span>' . $_GET['errorMessage'] . '</span>';
							echo '</div>';
						}
					?>
					<p class="specific">Inserisci i tuoi dati<p><br>
					<input type="username"name="username" placeholder="Username"><br>
					<input type="password"name="password" placeholder="Password"><br>
					<input type="submit" class="sub_b" value="Invia">
				</form>
			</div>
			<p class="help_text">Non possiedi ancora un account? Effettua la <a href="./registration.php" class="help_link">Registrazione</a>.</p>
		</div>
		
	</body>
</html>