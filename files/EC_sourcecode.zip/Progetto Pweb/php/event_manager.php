<?php
	session_start();
	require_once "./utility/eventcrate_db_connections.php";
	require_once "./utility/eventcrate_db_session.php";

	$event_id = $_GET['eventid'];
	$_SESSION['addressto'] = 'event_manager.php?eventid=' . $event_id . '';
	if (!isLogged()){
		    header('Location: ./sign_in.php');
		    exit;
    }
	if(isLogged()){
		global $EventCrateDb;
		$username = $_SESSION['username'];
		$queryText = "select * from eventi where creatore = '" . $username . "' and event_id = '" . $event_id . "'";
		$test = $EventCrateDb->performQuery($queryText);
		$check = mysqli_num_rows($test);
		if ($check == 0){
			header('Location: ./home.php?errorMessage="Permesso negato"');
		    exit;
		}
	}
?>
<!DOCTYPE=html>
<html lang="it">
	<head>
		<style>
		@import url('https://fonts.googleapis.com/css?family=Fredoka+One');
		@import url('https://fonts.googleapis.com/css?family=M+PLUS+Rounded+1c');
		</style>
		<meta charset="utf-8">
    	<meta name = "author" content = "Leonardo">
    	<meta name = "keywords" content = "eventcrate, events, event planner, online planner, event manager">
		<meta name = "description" content = "Crea, organizza o partecipa agli eventi direttamente tramite la nostra piattaforma online">
     	<link rel="stylesheet" href="./../css/event_manager.css" type="text/css" media="screen">
		<title>EventCrate - I miei eventi</title>
	</head>
	<body>
		<nav class="shift">
			<?php
				if (isLogged()){
					echo'<a href="./home.php"><img id = "nav_logo" src="./../css/img/logopng1.png" alt="EventCrate"></a>';
				}
				else {
					echo'<a href="./../index.php"><img id = "nav_logo" src="./../css/img/logopng1.png" alt="EventCrate"></a>';
				}
			?>
			<a href="./creationtool.php" class="nav_elem">Crea evento</a>
			<a href="./search.php" class="nav_elem">Cerca eventi</a>
			<a href="./myevents.php" class="nav_elem">I miei eventi</a>
			<a href="./help.php" class="nav_elem">Aiuto</a>
		<?php
			if (isLogged()){
				echo '<a href="./scripts/logout.php" id = "nav_elem_noteimg"><img class="helpimg" src="./../css/img/note.png" alt="Sign Up"><div class="t_nav">Esci</div></a>';
				echo '<a href="./profile.php" id = "nav_elem_userimg"><img class="helpimg" src="./../css/img/user.png" alt="Sign In"><div class="t_nav">Profilo</div></a>';
			}
			else {
				echo '<a href="./registration.php" id = "nav_elem_noteimg"><img class="helpimg" src="./../css/img/note.png" alt="Sign Up"><div class="t_nav">Registrati</div></a>';
				echo '<a href="./sign_in.php" id = "nav_elem_userimg"><img class="helpimg" src="./../css/img/user.png" alt="Sign In"><div class="t_nav">Entra</div></a>';
			}
		?>
		</nav>
	</body>
	<div class="invitation_m">
		<?php
			global $EventCrateDb;

			$event_id = $_GET['eventid'];
			$queryText = "select * from partecipazione where event_id ='" . $event_id . "'";
			$result = $EventCrateDb->performQuery($queryText);
			$num = mysqli_num_rows($result);
			echo'<div class="part">';
			echo'<h2 class="h_part"> Partecipanti </h2>';
			if ( $num == 0 ){
				echo'<p> Non ci sono partecipanti al momento </p>';
			}
			while($Row = $result->fetch_assoc()){
				echo'<div class="user_div">';
				echo'<p class="user_p"> ' . $Row['username'] . '';
				echo'<a class="block_p" href="./scripts/participation_scripts/block_p.php?userid=' . $Row['user_id'] . '&eventid=' . $event_id . '&username=' . $Row['username'] . '">Blocca</a>';
				echo'<a class="remove_p" href="./scripts/participation_scripts/remove_p.php?userid=' . $Row['user_id'] . '&eventid=' . $event_id . '&username=' . $Row['username'] . '">Rimuovi</a>';
				echo'</div>';
			}
			echo'</div>';

			$queryText = "select privato from eventi where event_id ='" . $event_id . "'";
			$result = $EventCrateDb->performQuery($queryText);
			$result = $result->fetch_assoc();
			if ($result['privato'] == 1){
				echo'<div class="part">';
				echo'<h2 class="h_part"> Richieste di partecipazione </h2>';
				$queryText = "select * from richieste_partecipazione where event_id ='" . $event_id . "'";
				$result = $EventCrateDb->performQuery($queryText);
				if ( mysqli_num_rows($result) == 0 ){
					echo'<p> Non ci sono richieste di partecipazione al momento </p>';
				}
				else {
					while($Row = $result->fetch_assoc()){
						echo'<div class="user_div">';
						echo'<p class="user_p"> ' . $Row['username'] . '';
						echo'<a class="block_p" href="./scripts/participation_scripts/block_p.php?userid=' . $Row['user_id'] . '&eventid=' . $event_id . '&username=' . $Row['username'] . '">Blocca</a>';
						echo'<a class="remove_p" href="./scripts/participation_scripts/remove_p.php?userid=' . $Row['user_id'] . '&eventid=' . $event_id . '&username=' . $Row['username'] . '">Rimuovi</a>';
						echo'<a class="accept_p" href="./scripts/participation_scripts/accept_p.php?userid=' . $Row['user_id'] . '&eventid=' . $event_id . '&username=' . $Row['username'] . '">Accetta</a>';
						echo'</div>';
					}
				}
				echo'</div>';
			}

		?>
	</div>
	<div class="delete">
		<?php
		echo'<h2 class="h_part"> Cancella evento </h2>';
		echo '<a class ="del" href="./scripts/delete_event.php?eventid=' . $event_id . '"><button>Cancella</button></a>';
		?>
	</div>
</html>
