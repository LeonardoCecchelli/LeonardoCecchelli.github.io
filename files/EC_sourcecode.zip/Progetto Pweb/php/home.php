<?php
	session_start();
	require_once "./utility/eventcrate_db_connections.php";
	require_once "./utility/eventcrate_db_session.php";

	$_SESSION['addressto'] = 'home.php';

	if (!isLogged()){
		    header('Location: ./sign_in.php');
		    exit;
    }
?>
<!DOCTYPE=html>
<html lang="it">
	<head>
		<style>
		@import url('https://fonts.googleapis.com/css?family=Fredoka+One');
		@import url('https://fonts.googleapis.com/css?family=M+PLUS+Rounded+1c');
		</style>
		<meta charset="utf-8">
    	<meta name = "author" content = "Leonardo">
    	<meta name = "keywords" content = "eventcrate, events, event planner, online planner, event manager">
		<meta name = "description" content = "Crea, organizza o partecipa agli eventi direttamente tramite la nostra piattaforma online">
     	<link rel="stylesheet" href="./../css/index.css" type="text/css" media="screen">
		<title>EventCrate - Home</title>
	</head>
	<body>
		<nav class="shift">
      <?php
        if (isLogged()){
          echo'<a href="./home.php"><img id = "nav_logo" src="./../css/img/logopng1.png" alt="EventCrate"></a>';
        }
        else {
          echo'<a href="./../index.php"><img id = "nav_logo" src="./../css/img/logopng1.png" alt="EventCrate"></a>';
        }
      ?>
      <a href="./creationtool.php" class="nav_elem">Crea evento</a>
      <a href="./search.php" class="nav_elem">Cerca eventi</a>
      <a href="./myevents.php" class="nav_elem" id = "create_nav">I miei eventi</a>
      <a href="./help.php" class="nav_elem">Aiuto</a>
    <?php
      if (isLogged()){
        echo '<a href="./scripts/logout.php" id = "nav_elem_noteimg"><img class="helpimg" src="./../css/img/note.png" alt="Sign Up"><div class="t_nav">Esci</div></a>';
        echo '<a href="./profile.php" id = "nav_elem_userimg"><img class="helpimg" src="./../css/img/user.png" alt="Sign In"><div class="t_nav">Profilo</div></a>';
      }
      else {
        echo '<a href="./registration.php" id = "nav_elem_noteimg"><img class="helpimg" src="./../css/img/note.png" alt="Sign Up"><div class="t_nav">Registrati</div></a>';
        echo '<a href="./sign_in.php" id = "nav_elem_userimg"><img class="helpimg" src="./../css/img/user.png" alt="Sign In"><div class="t_nav">Entra</div></a>';
      }
    ?>
		</nav>
		<div class="search">
			<h1 class="search_h1">Cerca il tuo evento</h1>
				<div class="search_form_box">
					<form id="search_form" action="./../php/search.php" method="get">
							<input type="text" name="name" placeholder="Nome evento">
							<select name="category" >
								<option value="all_c">Categoria</option>
                <option value="Affari">Affari</option>
								<option value="Musica">Musica</option>
								<option value="Sport e fitness">Sport e fitness</option>
								<option value="Gastronomia">Gastronomia</option>
								<option value="Film e media">Film e media</option>
								<option value="Arte">Arte</option>
								<option value="Moda">Moda</option>
								<option value="Viaggi e outdoor">Viaggi e outdoor</option>
								<option value="Feste">Feste</option>
								<option value="Eventi esclusivi">Eventi esclusivi</option>
								<option value="Corsi">Corsi</option>
								<option value="Motorsport">Motorsport</option>
								<option value="Seminari">Seminari</option>
							</select>
							<select name="regions" >
								<option value="all">Regione</option>
								<option value="Abruzzo">Abruzzo</option>
								<option value="Basilicata">Basilicata</option>
								<option value="Calabria">Calabria</option>
								<option value="Campania">Campania</option>
								<option value="Emilia_romagna">Emilia Romagna</option>
								<option value="Friuli_venezia_giulia">Friuli Venezia Giulia</option>
								<option value="Lazio">Lazio</option>
								<option value="Liguria">Liguria</option>
								<option value="Lombardia">Lombardia</option>
								<option value="Marche">Marche</option>
								<option value="Molise">Molise</option>
								<option value="Piemonte">Piemonte</option>
								<option value="Puglia">Puglia</option>
								<option value="Sardegna">Sardegna</option>
								<option value="Sicilia">Sicilia</option>
								<option value="Toscana">Toscana</option>
								<option value="Trentino_alto_adige">Trentino Alto Adige</option>
								<option value="Umbria">Umbria</option>
								<option value="Valle_d_aosta">Valle d'Aosta</option>
								<option value="Veneto">Veneto</option>
							</select>
							<input type="date" name="date">
						<input type="submit" name="sub_s" value="Cerca">
					</form>
				</div>
		</div>
		<div class="big_events_box">
			<h1>Eventi nelle tue vicinanze</h1>
		</div>
		<div class="category_nav">
			<h1>Naviga per categorie principali</h1>
			<div class="category_1">
				<a href="./search.php?name=&category=Musica&regions=all&date=&sub_s=Cerca">
					<h2 class="category_h2">Musica</h2>
					<p class="category_p">Concerti, festival musicali e feste da ballo</p>
				</a>
			</div>
			<div class="category_2">
				<a href="./search.php?name=&category=Sport+e+fitness&regions=all&date=&sub_s=Cerca">
					<h2 class="category_h2">Sport e fitness</h2>
					<p class="category_p">Lezioni di fitness, incontri sportivi</p>
				</a>
			</div>
			<div class="category_3">
				<a href="./search.php?name=&category=Gastronomia&regions=all&date=&sub_s=Cerca">
					<h2 class="category_h2">Gastronomia</h2>
					<p class="category_p">Cene, degustazioni e festival culinari</p>
				</a>
			</div>
			<div class="category_4">
				<a href="./search.php?name=&category=Film+e+media&regions=all&date=&sub_s=Cerca">
					<h2 class="category_h2">Film e media</h2>
					<p class="category_p">Festival cinematografici, eventi videoludici e spettacoli</p>
				</a>
			</div>
			<div class="category_5">
				<a href="./search.php?name=&category=Arte&regions=all&date=&sub_s=Cerca">
					<h2 class="category_h2">Arte</h2>
					<p class="category_p">Mostre e aste d'arte</p>
				</a>
			</div>
			<div class="category_6">
				<a href="./search.php?name=&category=Affari&regions=all&date=&sub_s=Cerca">
					<h2 class="category_h2">Affari</h2>
					<p class="category_p">Conventions e seminari riguardo business, finanza e marketing</p>
				</a>
			</div>
			<div class="category_7">
				<a href="./search.php?name=&category=Moda&regions=all&date=&sub_s=Cerca">
					<h2 class="category_h2">Moda</h2>
					<p class="category_p">Sfilate, fashion weeks e inaugurazioni</p>
				</a>
			</div>
			<div class="category_8">
				<a href="./search.php?name=&category=Viaggi+e+outdoor&regions=all&date=&sub_s=Cerca">
					<h2 class="category_h2">Viaggi e outdoor</h2>
					<p class="category_p">Escursioni, visite guidate ed eventi all'aperto </p>
				</a>
			</div>
			<div class="category_9">
				<a href="./search.php?name=&category=Feste&regions=all&date=&sub_s=Cerca">
					<h2 class="category_h2">Feste</h2>
					<p class="category_p">Aperitivi casual, eventi per single e feste private</p>
				</a>
			</div>
		</div>
	</body>
</html>
