<?php
	session_start();
    include "./utility/eventcrate_db_session.php";
	
    if (isLogged()){
		    header('Location: ./home.php');
		    exit;
    }	
?>
<!DOCTYPE=html>
<html lang="it">
		<head>
		<style>
		@import url('https://fonts.googleapis.com/css?family=Fredoka+One');
		@import url('https://fonts.googleapis.com/css?family=M+PLUS+Rounded+1c');
		</style>
		<meta charset="utf-8"> 
		<meta name = "author" content = "Leonardo">
		<meta name = "keywords" content = "eventcrate, events, event planner, online planner, event manager, registration">
		<meta name = "description" content = "Crea, organizza o partecipa agli eventi direttamente tramite la nostra piattaforma online">
		<link rel="stylesheet" href="./../css/registration.css" type="text/css" media="screen">
		<script type="text/javascript" src="./../js/registration.js"></script>
		<title>EventCrate - Registrazione</title>
	</head>
	<body>
		<div class="top_h1">
		<a href="./../index.php"><img class="back-arrow" src="./../css/img/left-arrow.png" alt="indietro"></a>
		<h1>Registrati</h1>
		</div>
		<div class="registration_box">
			<form id="reg_form" action="./scripts/register.php" method="post">
				<?php
					if (isset($_GET['errorMessage'])){
						echo '<div class="sign_in_error">';
						echo '<span>' . $_GET['errorMessage'] . '</span>';
						echo '</div>';
					}
				?>
				<div class="gen_info">
					<p class="specific">Informazioni generali<p><br>
					<input type="username" name="username" placeholder="Username" required><br>
					<p class="p_h">Questo sara' il nome visibile agli altri utenti</p><br>
					<input type="email" name="email" placeholder="Email" required><br>
					<input type="text" name="firstname" placeholder="Nome" required><br>
					<input type="text" name="lastname" placeholder="Cognome"><br>
				</div>
				<div class="add_info">
					<p class="specific">Dicci qualcosa di piu' sul tuo conto, in questo modo potremo fornirti 
					informazioni piu' accurate riguardo agli eventi che ti interessano veramente!</p>
					Quando sei nato?<br>
					<input type="date" name="birthdate"><br>
					In quale regione abiti?<br>
					<select name="regions">
						<option value="all">Regione</option>
						<option value="Abruzzo">Abruzzo</option>
						<option value="Basilicata">Basilicata</option>
						<option value="Calabria">Calabria</option>
						<option value="Campania">Campania</option>
						<option value="Emilia_romagna">Emilia Romagna</option>
						<option value="Friuli_venezia_giulia">Friuli Venezia Giulia</option>
						<option value="Lazio">Lazio</option>
						<option value="Liguria">Liguria</option>
						<option value="Lombardia">Lombardia</option>
						<option value="Marche">Marche</option>
						<option value="Molise">Molise</option>
						<option value="Piemonte">Piemonte</option>
						<option value="Puglia">Puglia</option>
						<option value="Sardegna">Sardegna</option>
						<option value="Sicilia">Sicilia</option>
						<option value="Toscana">Toscana</option>
						<option value="Trentino_alto_adige">Trentino Alto Adige</option>
						<option value="Umbria">Umbria</option>
						<option value="Valle_d_aosta">Valle d'Aosta</option>
						<option value="Veneto">Veneto</option>
					</select><br>
					In quale citta' abiti?<br>
					<input type="text"name="city" placeholder="Citta'"><br>
				</div>
				<div class="password_box">
					<p class="specific">Scegli una password<p><br>
					<input type="password" name="password" placeholder="Password" required><br>
					<input type="password" name="password_r" placeholder="Re-inserisci la password" required><br>
					<input type="submit" class="sub_b" value="Invia">
				</div>
			</form>
			<p class="help_text">Possiedi gia' un account? Effettua il <a href="./sign_in.php" class="help_link">Login</a>.</p>
		</div>
	</body>
</html>

