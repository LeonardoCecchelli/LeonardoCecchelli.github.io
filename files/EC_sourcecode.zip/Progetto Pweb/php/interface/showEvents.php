<?php

	function eventList($result){

		$num = mysqli_num_rows($result);
		if($num <= 0) {
			echo '<p id="error_code">Errore durante la ricerca</p>';	
			return;
		}

		while($Erow = $result->fetch_assoc()){
			if ($Erow['regione'] == 'Emilia_romagna'){
				$Erow['regione'] = "Emilia Romagna";
			}
			if ($Erow['regione'] == 'Friuli_venezia_giulia'){
				$Erow['regione'] = "Friuli Venezia Giulia";
			}
			if ($Erow['regione'] == 'Trentino_alto_adige'){
				$Erow['regione'] = "Trentino Alto Adige";
			}
			if ($Erow['regione'] == 'Valle_d_aosta'){
				$Erow['regione'] = "Valle d' Aosta";
			}

			$eventid = $Erow['event_id'];
			echo'<div class ="event_wrap">';
			echo'<a href="./eventpage.php?eventid=' . $eventid . '" class="event_link">';
			echo'<img src="interface/showImage.php?id=' . $eventid . 'alt="Immagine" class="event_image">';
			echo'<h2 class="event_name">' . $Erow['nome_evento'] . '</h2>';
			echo'<p class="event_info">' . $Erow['data'] .',  '. $Erow['orario'] . '</p>';
			echo'<p class="event_info">' . $Erow['via'] . ', ' . $Erow['citta'] . ', ' . $Erow['regione'] . '</p>';
			if ($Erow['privato']){
				echo'<p class="priv">Evento privato</p>';
			}
			else {
				echo'<p class="pubb">Evento pubblico</p>';
			}
			echo'<h3 class="event_info">Creato da ' . $Erow['creatore'] . '</h3>';
			echo'</a>';
			echo'</div>';
		}
	}




?>
