<?php
	require_once "./../utility/eventcrate_db_connections.php";
	require_once "./../utility/eventcrate_db_session.php";
	
	if(isset($_GET['id'])){
		global $EventCrateDb;
		$id = $EventCrateDb->sqlInjectionFilter($_GET['id']);
		$queryText = " select * from eventi where event_id = '" . $id . "'";
		$result = $EventCrateDb->performQuery($queryText);
		while($row = $result->fetch_assoc()){
			$image_data = $row['immagine'];
		}
		header("content-type: image/jpeg");
		if ($image_data){
			echo $image_data;
		}
	}
	else {
		echo "Errore caricamento immagine";
	}
?>