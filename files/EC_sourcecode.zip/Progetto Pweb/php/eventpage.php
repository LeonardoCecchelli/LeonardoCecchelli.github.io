<?php
	session_start();
	require_once "./utility/eventcrate_db_connections.php";
	require_once "./utility/eventcrate_db_session.php";

	$eventid = $_GET['eventid'];
	if(isset($_SESSION['user_id'])){
		$userid = $_SESSION['user_id'];
	}
	else {
		$userid = NULL;
		$username = NULL;
	}
	$_SESSION['addressto'] = 'eventpage.php?eventid='. $eventid .'';

?>

<!DOCTYPE=html>
<html lang="it">
	<head>
		<style>
		@import url('https://fonts.googleapis.com/css?family=Fredoka+One');
		@import url('https://fonts.googleapis.com/css?family=M+PLUS+Rounded+1c');
		</style>
		<meta charset="utf-8">
    	<meta name = "author" content = "Leonardo">
    	<meta name = "keywords" content = "eventcrate, events, event planner, online planner, event manager">
		<meta name = "description" content = "Crea, organizza o partecipa agli eventi direttamente tramite la nostra piattaforma online">
     	<link rel="stylesheet" href="./../css/eventpage.css" type="text/css" media="screen">
		<title>EventCrate - Cerca un evento</title>
	</head>
	<body>
		<nav class="shift">
			<?php
				if (isLogged()){
					echo'<a href="./home.php"><img id = "nav_logo" src="./../css/img/logopng1.png" alt="EventCrate"></a>';
				}
				else {
					echo'<a href="./../index.php"><img id = "nav_logo" src="./../css/img/logopng1.png" alt="EventCrate"></a>';
				}
			?>
			<a href="./creationtool.php" class="nav_elem">Crea evento</a>
			<a href="./search.php" class="nav_elem">Cerca eventi</a>
			<a href="./myevents.php" class="nav_elem">I miei eventi</a>
			<a href="./help.php" class="nav_elem">Aiuto</a>
		<?php
			if (isLogged()){
				echo '<a href="./scripts/logout.php" id = "nav_elem_noteimg"><img class="helpimg" src="./../css/img/note.png" alt="Sign Up"><div class="t_nav">Esci</div></a>';
				echo '<a href="./profile.php" id = "nav_elem_userimg"><img class="helpimg" src="./../css/img/user.png" alt="Sign In"><div class="t_nav">Profilo</div></a>';
			}
			else {
				echo '<a href="./registration.php" id = "nav_elem_noteimg"><img class="helpimg" src="./../css/img/note.png" alt="Sign Up"><div class="t_nav">Registrati</div></a>';
				echo '<a href="./sign_in.php" id = "nav_elem_userimg"><img class="helpimg" src="./../css/img/user.png" alt="Sign In"><div class="t_nav">Entra</div></a>';
			}
		?>
		</nav>
		<div class="search_res">
			<?php
				global $EventCrateDb;

				$queryText = "select * from eventi where event_id = '" . $eventid . "'";
				$result = $EventCrateDb->performQuery($queryText);
				$num = mysqli_num_rows($result);
				if ($num > 1){
					echo"<p>Si e' verificato un errore nel caricamento</p>";
				}
				if ($num == 0){
					echo"<p>Si e' verificato un errore nel caricamento, l' evento cercato potrebbe essere stato rimosso</p>";
				}
				echo'<div class="event_res">';
				$event = $result->fetch_assoc();
				echo'<img src="interface/showImage.php?id=' . $eventid . 'alt="Immagine" class="event_image">';
				if ($event['regione'] == 'Emilia_romagna'){
					$event['regione'] = "Emilia Romagna";
				}
				if ($event['regione'] == 'Friuli_venezia_giulia'){
					$event['regione'] = "Friuli Venezia Giulia";
				}
				if ($event['regione'] == 'Trentino_alto_adige'){
					$event['regione'] = "Trentino Alto Adige";
				}
				if ($event['regione'] == 'Valle_d_aosta'){
					$event['regione'] = "Valle d' Aosta";
				}
				echo'<div class= "event_g_info">';
				echo'<h2 class="event_name">' . $event['nome_evento'] . '</h2>';
				echo'<h3 class="event_cat">' . $event['categoria'] . '</h3>';
				echo'<p class="event_info">' . $event['data'] .',  '. $event['orario'] . '</p>';
				echo'<p class="event_info">' . $event['via'] . ', ' . $event['citta'] . ', ' . $event['regione'] . '</p>';
				echo '</div>';
				echo'<div class= "event_d_info">';
				echo'<p class="event_desc">' . $event['descrizione'] . '</p>';
				echo'<p class="event_desc_c">Creato da ' . $event['creatore'] . '</p>';
				/* immagine privato o pubblico */
				if(isset($_SESSION['username'])){
					$username = $_SESSION['username'];
				}
				$queryText = "select * from partecipazione where event_id = '" . $eventid . "' and user_id = '" . $userid . "'";
				$result = $EventCrateDb->performQuery($queryText);
				$result_p = mysqli_num_rows($result);
				$queryText = "select * from richieste_partecipazione where event_id = '" . $eventid . "' and user_id = '" . $userid . "'";
				$result= $EventCrateDb->performQuery($queryText);
				$result_r = mysqli_num_rows($result);
				$queryText = "select * from richieste_rifiutate where event_id = '" . $eventid . "' and user_id = '" . $userid . "'";
				$result = $EventCrateDb->performQuery($queryText);
				$result_rif = mysqli_num_rows($result);
				$queryText = "select * from eventi where event_id = '" . $eventid . "' and creatore = '" . $username . "'";
				$result = $EventCrateDb->performQuery($queryText);
				$result_creatore = mysqli_num_rows($result);
				if ($result_creatore != 0){
					echo'<div class="request">';
					echo"<p class='creator'>Sei l'organizzatore di questo evento</p>";
					echo'</div>';
				}
				else {
					if ($result_p == 0 && $result_r == 0 && $result_rif == 0){
						if($event['privato']==1){
							echo'<div class="request">';
							echo'<a href="./scripts/participation_scripts/request_p.php?eventid=' . $eventid . '">Richiedi di partecipare</a>';
							echo'</div>';
						}
						else {
							echo'<div class="request">';
							echo'<a href="./scripts/participation_scripts/participate.php?eventid=' . $eventid . '">Partecipa</a>';
							echo'</div>';
						}
					}
					else {
						if($result_p == 1){
							echo'<div class="request">';
							echo'<a href="./scripts/participation_scripts/delete_p.php?eventid=' . $eventid . '">';
							echo"Partecipero'</a>";
							echo'</div>';
						}
						if($result_r == 1){
							echo'<div class="request">';
							echo'<a href="./scripts/participation_scripts/delete_r.php?eventid=' . $eventid . '">Richiesta inviata</a>';
							echo'</div>';
						}
						if($result_rif == 1) {
							echo'<div class="request">';
							echo'<p class="rif">Partecipazione negata</p>';
							echo'</div>';
						}
						if ($result_p > 1 || $result_r > 1 || $result_rif > 1){
							echo'<div class="request">';
							echo'<p class="rif">Errore partecipazione</p>';
							echo'</div>';
						}
					}
					echo '</div>';
				}
			?>
		</div>
	</body>
</html>
