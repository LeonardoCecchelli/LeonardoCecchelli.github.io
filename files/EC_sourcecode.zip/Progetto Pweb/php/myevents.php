<?php
	session_start();
	require_once "./utility/eventcrate_db_connections.php";
	require_once "./utility/eventcrate_db_session.php";

	$_SESSION['addressto'] = 'myevents.php';
	if (!isLogged()){
		    header('Location: ./sign_in.php');
		    exit;
    }
?>

<!DOCTYPE=html>
<html lang="it">
	<head>
		<style>
		@import url('https://fonts.googleapis.com/css?family=Fredoka+One');
		@import url('https://fonts.googleapis.com/css?family=M+PLUS+Rounded+1c');
		</style>
		<meta charset="utf-8">
    	<meta name = "author" content = "Leonardo">
    	<meta name = "keywords" content = "eventcrate, events, event planner, online planner, event manager">
		<meta name = "description" content = "Crea, organizza o partecipa agli eventi direttamente tramite la nostra piattaforma online">
     	<link rel="stylesheet" href="./../css/search.css" type="text/css" media="screen">
		<title>EventCrate - I miei eventi</title>
	</head>
	<body>
		<nav class="shift">
			<?php
				if (isLogged()){
					echo'<a href="./home.php"><img id = "nav_logo" src="./../css/img/logopng1.png" alt="EventCrate"></a>';
				}
				else {
					echo'<a href="./../index.php"><img id = "nav_logo" src="./../css/img/logopng1.png" alt="EventCrate"></a>';
				}
			?>
			<a href="./creationtool.php" class="nav_elem">Crea evento</a>
			<a href="./search.php" class="nav_elem">Cerca eventi</a>
			<a href="./myevents.php" class="nav_elem" id = "create_nav">I miei eventi</a>
			<a href="./help.php" class="nav_elem">Aiuto</a>
		<?php
			if (isLogged()){
				echo '<a href="./scripts/logout.php" id = "nav_elem_noteimg"><img class="helpimg" src="./../css/img/note.png" alt="Sign Up"><div class="t_nav">Esci</div></a>';
				echo '<a href="./profile.php" id = "nav_elem_userimg"><img class="helpimg" src="./../css/img/user.png" alt="Sign In"><div class="t_nav">Profilo</div></a>';
			}
			else {
				echo '<a href="./registration.php" id = "nav_elem_noteimg"><img class="helpimg" src="./../css/img/note.png" alt="Sign Up"><div class="t_nav">Registrati</div></a>';
				echo '<a href="./sign_in.php" id = "nav_elem_userimg"><img class="helpimg" src="./../css/img/user.png" alt="Sign In"><div class="t_nav">Entra</div></a>';
			}
		?>
		</nav>
		<div class="search_res">
		<?php
			global $EventCrateDb;

			$user_id = $_SESSION['user_id'];
			$username = $_SESSION['username'];
			$queryText = "select * from partecipazione where user_id = '" . $user_id . "' and event_id not in ( select event_id from eventi where creatore = '" . $username . "')  order by data_evento";
			$result = $EventCrateDb->performQuery($queryText);
			$num = mysqli_num_rows($result);
			echo'<h2>Eventi a cui parteciperai</h2>';
			if ($num == 0){
				echo'<p>Al momento non hai eventi in programma</p>';
			}
			else {
				while($row = $result->fetch_assoc()){
					$event_id = $row['event_id'];
					$queryText2 = "select * from eventi where event_id = '" . $event_id . "'";
					$result2 = $EventCrateDb->performQuery($queryText2);
					$event = $result2->fetch_assoc();
					if ($event['regione'] == 'Emilia_romagna'){
						$event['regione'] = "Emilia Romagna";
					}
					if ($event['regione'] == 'Friuli_venezia_giulia'){
						$event['regione'] = "Friuli Venezia Giulia";
					}
					if ($event['regione'] == 'Trentino_alto_adige'){
						$event['regione'] = "Trentino Alto Adige";
					}
					if ($event['regione'] == 'Valle_d_aosta'){
						$event['regione'] = "Valle d' Aosta";
					}
					$queryText5 = "select * from partecipazione where event_id = '" . $event_id . "'";
					$result5 = $EventCrateDb->performQuery($queryText5);
					$num_part1 = mysqli_num_rows($result5);
					echo'<div class ="event_wrap">';
					echo'<a href="./eventpage.php?eventid=' . $event_id . '" class="event_link">';
					echo'<img src="interface/showImage.php?id=' . $event_id . 'alt="Immagine" class="event_image">';
					echo'<h3 class="event_name">' . $event['nome_evento'] . '</h3>';
					echo'<p class="event_info">' . $event['data'] .',  '. $event['orario'] . '</p>';
					echo'<p class="event_info">' . $event['via'] . ', ' . $event['citta'] . ', ' . $event['regione'] . '</p>';
					echo'<p class="event_num_part">Partecipanti: ' . $num_part1 . '</p>';
					echo'</div>';
				}
			}
		?>
		</div>
	<div class="search_res">
			<?php
			global $EventCrateDb;

			$username = $_SESSION['username'];
			$queryText3 = "select * from eventi where creatore = '" . $username . "' order by data";
			$result3 = $EventCrateDb->performQuery($queryText3);
			$num3 = mysqli_num_rows($result3);
			echo'<h2>Eventi organizzati</h2>';
			if ($num3 == 0){
				echo'<p>Al momento non hai organizzato alcun evento</p>';
			}
			else {
				while($event2 = $result3->fetch_assoc()){
					$event_id2 = $event2['event_id'];
					if ($event2['regione'] == 'Emilia_romagna'){
						$event2['regione'] = "Emilia Romagna";
					}
					if ($event2['regione'] == 'Friuli_venezia_giulia'){
						$event2['regione'] = "Friuli Venezia Giulia";
					}
					if ($event2['regione'] == 'Trentino_alto_adige'){
						$event2['regione'] = "Trentino Alto Adige";
					}
					if ($event2['regione'] == 'Valle_d_aosta'){
						$event2['regione'] = "Valle d' Aosta";
					}
					$queryText4 = "select * from partecipazione where event_id = '" . $event_id2 . "'";
					$result4 = $EventCrateDb->performQuery($queryText4);
					$num_part = mysqli_num_rows($result4);
					echo'<div class ="event_wrap">';
					echo'<a href="./event_manager.php?eventid=' . $event_id2 . '" class="event_link">';
					echo'<img src="interface/showImage.php?id=' . $event_id2 . 'alt="Immagine" class="event_image">';
					echo'<h3 class="event_name">' . $event2['nome_evento'] . '</h3>';
					echo'<p class="event_info">' . $event2['data'] .',  '. $event2['orario'] . '</p>';
					echo'<p class="event_info">' . $event2['via'] . ', ' . $event2['citta'] . ', ' . $event2['regione'] . '</p>';
					echo'<p class="event_num_part">Partecipanti: ' . $num_part . '</p>';
					echo'</div>';
				}
			}

		?>

		</div>

	</body>
</html>
