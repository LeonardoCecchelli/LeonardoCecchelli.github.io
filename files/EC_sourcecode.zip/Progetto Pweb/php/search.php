<?php
	session_start();
	require_once "./utility/eventcrate_db_connections.php";
	require_once "./utility/eventcrate_db_session.php";

	$_SESSION['addressto'] = 'search.php';

	if (isset($_GET['name'])){
		$title = $_GET['name'];
	}
	else {
		$title = NULL;
	}
	if (isset($_GET['category'])){
		$category = $_GET['category'];
	}
	else {
		$category = NULL;
	}
	if (isset($_GET['regions'])){
		$region = $_GET['regions'];
	}
	else {
		$region = NULL;
	}
	if (isset($_GET['date'])){
		$date = $_GET['date'];
	}
	else {
		$date = NULL;
	}
?>
<!DOCTYPE=html>
<html lang="it">
	<head>
		<style>
		@import url('https://fonts.googleapis.com/css?family=Fredoka+One');
		@import url('https://fonts.googleapis.com/css?family=M+PLUS+Rounded+1c');
		</style>
		<meta charset="utf-8">
    	<meta name = "author" content = "Leonardo">
    	<meta name = "keywords" content = "eventcrate, events, event planner, online planner, event manager">
		<meta name = "description" content = "Crea, organizza o partecipa agli eventi direttamente tramite la nostra piattaforma online">
     	<link rel="stylesheet" href="./../css/search.css" type="text/css" media="screen">
		<title>EventCrate - Cerca un evento</title>
	</head>
	<body>
		<nav class="shift">
			<?php
				if (isLogged()){
					echo'<a href="./home.php"><img id = "nav_logo" src="./../css/img/logopng1.png" alt="EventCrate"></a>';
				}
				else {
					echo'<a href="./../index.php"><img id = "nav_logo" src="./../css/img/logopng1.png" alt="EventCrate"></a>';
				}
			?>
			<a href="./creationtool.php" class="nav_elem">Crea evento</a>
			<a href="./search.php" class="nav_elem" id = "create_nav">Cerca eventi</a>
			<a href="./myevents.php" class="nav_elem">I miei eventi</a>
			<a href="./help.php" class="nav_elem">Aiuto</a>
		<?php
			if (isLogged()){
				echo '<a href="./scripts/logout.php" id = "nav_elem_noteimg"><img class="helpimg" src="./../css/img/note.png" alt="Sign Up"><div class="t_nav">Esci</div></a>';
				echo '<a href="./profile.php" id = "nav_elem_userimg"><img class="helpimg" src="./../css/img/user.png" alt="Sign In"><div class="t_nav">Profilo</div></a>';
			}
			else {
				echo '<a href="./registration.php" id = "nav_elem_noteimg"><img class="helpimg" src="./../css/img/note.png" alt="Sign Up"><div class="t_nav">Registrati</div></a>';
				echo '<a href="./sign_in.php" id = "nav_elem_userimg"><img class="helpimg" src="./../css/img/user.png" alt="Sign In"><div class="t_nav">Entra</div></a>';
			}
		?>
		</nav>
		<div class="search">
			<h1 class="search_h1">Cerca il tuo evento</h1>
				<div class="search_form_box">
					<form id="search_form" method="get">
							<input type="text" name="name" placeholder="Nome evento">
							<select name="category" >
								<option value="all_c">Categoria</option>
								<option value="Affari">Affari</option>
								<option value="Musica">Musica</option>
								<option value="Sport e fitness">Sport e fitness</option>
								<option value="Gastronomia">Gastronomia</option>
								<option value="Film e media">Film e media</option>
								<option value="Arte">Arte</option>
								<option value="Moda">Moda</option>
								<option value="Viaggi e outdoor">Viaggi e outdoor</option>
								<option value="Feste">Feste</option>
								<option value="Eventi esclusivi">Eventi esclusivi</option>
								<option value="Corsi">Corsi</option>
								<option value="Motorsport">Motorsport</option>
								<option value="Seminari">Seminari</option>
							</select>
							<select name="regions" >
								<option value="all">Regione</option>
								<option value="Abruzzo">Abruzzo</option>
								<option value="Basilicata">Basilicata</option>
								<option value="Calabria">Calabria</option>
								<option value="Campania">Campania</option>
								<option value="Emilia_romagna">Emilia Romagna</option>
								<option value="Friuli_venezia_giulia">Friuli Venezia Giulia</option>
								<option value="Lazio">Lazio</option>
								<option value="Liguria">Liguria</option>
								<option value="Lombardia">Lombardia</option>
								<option value="Marche">Marche</option>
								<option value="Molise">Molise</option>
								<option value="Piemonte">Piemonte</option>
								<option value="Puglia">Puglia</option>
								<option value="Sardegna">Sardegna</option>
								<option value="Sicilia">Sicilia</option>
								<option value="Toscana">Toscana</option>
								<option value="Trentino_alto_adige">Trentino Alto Adige</option>
								<option value="Umbria">Umbria</option>
								<option value="Valle_d_aosta">Valle d'Aosta</option>
								<option value="Veneto">Veneto</option>
							</select>
							<input type="date" name="date">
						<input type="submit" name="sub_s" value="Cerca">
					</form>
				</div>
		</div>
		<div class="search_res">
			<?php
				include "./interface/showEvents.php";

				global $EventCrateDb;

				if ($title != NULL){
					$s_title = "nome_evento='" . $title . "'";
				}
				else {
					$s_title ="nome_evento is not null";
				}
				if ($category != 'all_c'){
					$s_category = " and categoria='" . $category . "'";
				}
				else {
					$s_category =" and categoria is not null";
				}
				if ($region != 'all'){
					$s_region = " and regione='" . $region . "'";
				}
				else {
					$s_region =" and regione is not null";
				}
				if ($date != NULL){
					$s_date = " and data='" . $date . "'";
				}
				else {
					$s_date =" and data is not null";
				}
				$queryText = "select * from eventi where " . $s_title . "" . $s_category . "" . $s_region . "" . $s_date . "";
				$result = $EventCrateDb->performQuery($queryText);
				$num = mysqli_num_rows($result);
				if ($region == 'Emilia_romagna'){
					$region = "Emilia Romagna";
				}
				if ($region == 'Friuli_venezia_giulia'){
					$region = "Friuli Venezia Giulia";
				}
				if ($region == 'Trentino_alto_adige'){
					$region = "Trentino Alto Adige";
				}
				if ($region == 'Valle_d_aosta'){
					$region = "Valle d' Aosta";
				}
				echo'<div class="event_res">';
				if ($title != NULL){
					echo'<h3 class="event_res_fields">' . $title . '</h3>';
				}
				if ($category != 'all_c' && $category != NULL){
					echo'<h3 class="event_res_fields">' . $category . '</h3>';
				}
				if ($region != 'all' && $region != NULL){
					echo'<h3 class="event_res_fields">' . $region . '</h3>';
				}
				if ($date != NULL){
					echo'<h3 class="event_res_fields">' . $date . '</h3>';
				}
				echo'</div>';
				if ($num <= 0){
					echo '<p>Al momento non ci sono eventi in programma</p>';
				}
				if ($num > 0){
					eventList($result);
					$result->close();
				}
			?>
		</div>
	</body>
</html>
