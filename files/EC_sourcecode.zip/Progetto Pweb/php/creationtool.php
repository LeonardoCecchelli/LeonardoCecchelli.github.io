<?php
	session_start();
    include "./utility/eventcrate_db_session.php";

	$_SESSION['addressto'] = 'creationtool.php';

    if (!isLogged()){
		    header('Location: ./sign_in.php');
		    exit;
    }
?>
<!DOCTYPE=html>
<html lang="it">
	<head>
		<style>
		@import url('https://fonts.googleapis.com/css?family=Fredoka+One');
		@import url('https://fonts.googleapis.com/css?family=M+PLUS+Rounded+1c');
		</style>
		<meta charset="utf-8">
    	<meta name = "author" content = "Leonardo">
    	<meta name = "keywords" content = "eventcrate, events, event planner, online planner, event manager">
		<meta name = "description" content = "Crea, organizza o partecipa agli eventi direttamente tramite la nostra piattaforma online">
     	<link rel="stylesheet" href="./../css/creationtool.css" type="text/css" media="screen">
		<title>EventCrate - Crea il tuo evento</title>
	</head>
	<body>
		<nav class="shift">
			<a href="./home.php"><img id = "nav_logo" src="./../css/img/logopng1.png" alt="EventCrate"></a>
			<a href="./creationtool.php" id = "create_nav" class="nav_elem">Crea evento</a>
			<a href="./search.php" class="nav_elem">Cerca eventi</a>
			<a href="./myevents.php" class="nav_elem">I miei eventi</a>
			<a href="#about" class="nav_elem">Aiuto</a>
			<a href="./scripts/logout.php" id = "nav_elem_noteimg"><img class="helpimg" src="./../css/img/note.png" alt="Sign Up"><div class="t_nav">Esci</div></a>
			<a href="./profile.php" id = "nav_elem_userimg"><img class="helpimg" src="./../css/img/user.png" alt="Sign In"><div class="t_nav">Profilo</div></a>
		</nav>
		<div class="dynamic_helper_box">
		</div>
		<form id="event_tool" action="./scripts/upload.php" method="post" enctype="multipart/form-data">
			<div class="creationbox">
				<h1>Nome e descrizione del tuo evento</h1>
				<input type="text" name="title" placeholder="Titolo"><br>
				<textarea id="description" type="textarea" name="description" placeholder="Descrizione e informazioni generali sul tuo evento"></textarea><br>
				<p class="suggestion">Cerca di descrivere il tuo evento specificando come si svolgera', l'abbigliamento richiesto, possibili costi e altro. Piu' informazioni fornirai e piu' sara' facile
				per gli altri utenti decidere se partecipare o meno.</p>
			</div>
			<div class="creationbox">
				<h1>Categoria, localita', data e orario del tuo evento</h1>
				<select name="category" >
					<option value="all_c">Categoria</option>
					<option value="Affari">Affari</option>
					<option value="Musica">Musica</option>
					<option value="Sport e fitness">Sport e fitness</option>
					<option value="Gastronomia">Gastronomia</option>
					<option value="Film e media">Film e media</option>
					<option value="Arte">Arte</option>
					<option value="Moda">Moda</option>
					<option value="Viaggi e outdoor">Viaggi e outdoor</option>
					<option value="Feste">Feste</option>
					<option value="Eventi esclusivi">Eventi esclusivi</option>
					<option value="Corsi">Corsi</option>
					<option value="Motorsport">Motorsport</option>
					<option value="Seminari">Seminari</option>
				</select><br>
				<p class="suggestion"> Inserisci la regione nella quale l'evento prendera' luogo</p>
				<select name="regions" >
					<option value="all">Regione</option>
					<option value="Abruzzo">Abruzzo</option>
					<option value="Basilicata">Basilicata</option>
					<option value="Calabria">Calabria</option>
					<option value="Campania">Campania</option>
					<option value="Emilia_romagna">Emilia Romagna</option>
					<option value="Friuli_venezia_giulia">Friuli Venezia Giulia</option>
					<option value="Lazio">Lazio</option>
					<option value="Liguria">Liguria</option>
					<option value="Lombardia">Lombardia</option>
					<option value="Marche">Marche</option>
					<option value="Molise">Molise</option>
					<option value="Piemonte">Piemonte</option>
					<option value="Puglia">Puglia</option>
					<option value="Sardegna">Sardegna</option>
					<option value="Sicilia">Sicilia</option>
					<option value="Toscana">Toscana</option>
					<option value="Trentino_alto_adige">Trentino Alto Adige</option>
					<option value="Umbria">Umbria</option>
					<option value="Valle_d_aosta">Valle d'Aosta</option>
					<option value="Veneto">Veneto</option>
				</select><br>
				<p class="suggestion"> Inserisci la data e ora di inizio del tuo evento</p>
				<input type="text" name="city" placeholder="Citta'"><br>
				<input type="text" name="address" placeholder="Indirizzo"><br>
				<p class="suggestion"> Inserisci la data e ora di inizio del tuo evento</p>
				<input type="date" name="date"><br>
				<input type="time" name="time"><br>
			</div>
			<div class="creationbox">
				<h1>Immagine di copertina</h1>
				<input type="file" name="image">
				<p class="suggestion">L'immagine di copertina e' un elemento molto importante per attrarre l'attenzione degli altri utenti. Il formato dell' immagine deve
				essere ti tipo jpeg (.jpg) e la dimensione consigliata e' 400x400 pixel.</p>
			</div>
			<div class="creationbox">
				<h1>Rendi l'evento privato</h1>
				<label class="switch">
					<input type="checkbox" name="private" value="1">
					<span class="slider round"></span>
				</label>
				<p class="suggestion"> Rendendo il tuo evento privato gli altri utenti dovranno effettuare una richiesta di partecipazione per poter apparire tra i partecipanti.
				Potrai accettare o rifiutare le richieste dall'apposito pannello di gestione del tuo evento.</p>
			</div>
			<div class="creationbox">
				<h1>Conferma</h1>
				<input type="submit" class="create" value="Crea Evento">
				<p class="suggestion">Una volta completati tutti i passi precedenti sei pronto per creare il tuo evento! Una volta creato l'evento apparira' nella sezione "I miei eventi" dalla quale potrai
				accedere al pannello di gestione dell'evento.</p>
			</div>
		</form>
	</body>
</html>
