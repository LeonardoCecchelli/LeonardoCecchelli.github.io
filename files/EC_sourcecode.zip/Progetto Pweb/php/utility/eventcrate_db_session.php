<?php
	
	function CreateSession($username, $user_id){
		$_SESSION['user_id'] = $user_id;
		$_SESSION['username'] = $username;
	}
	
	function isLogged(){		
		if(isset($_SESSION['user_id']))
			return $_SESSION['user_id'];
		else
			return false;
	}

?>