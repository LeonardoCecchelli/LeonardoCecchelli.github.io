<?php
	$dbHostname = "localhost";
	$dbUsername = "root"; 
	$dbPassword = "selecta"; 
	$dbName = "eventcrate_db";
?>