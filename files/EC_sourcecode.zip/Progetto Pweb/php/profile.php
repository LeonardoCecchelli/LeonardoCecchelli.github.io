<!DOCTYPE=html>
<?php
	session_start();
	require_once "./utility/eventcrate_db_connections.php";
    include "./utility/eventcrate_db_session.php";
	
	$_SESSION['addressto'] = 'profile.php';
	
    if (!isLogged()){
		    header('Location: ./sign_in.php');
		    exit;
    }
?>
<html lang="it">
		<head>
		<style>
		@import url('https://fonts.googleapis.com/css?family=Fredoka+One');
		@import url('https://fonts.googleapis.com/css?family=M+PLUS+Rounded+1c');
		</style>
		<meta charset="utf-8"> 
		<meta name = "author" content = "Leonardo">
		<meta name = "keywords" content = "eventcrate, events, event planner, online planner, event manager, registration">
		<meta name = "description" content = "Crea, organizza o partecipa agli eventi direttamente tramite la nostra piattaforma online">
		<link rel="stylesheet" href="./../css/profile.css" type="text/css" media="screen">
		<script type="text/javascript" src="./../js/registration.js"></script>
		<title>EventCrate - Profilo</title>
	</head>
	<body>
		<div class="top_h1">
		<a href="./home.php"><img class="back-arrow" src="./../css/img/left-arrow.png" alt="indietro"></a>
		<h1>Il tuo profilo</h1>
		</div>
		<div class="info_box">
			<?php
						if (isset($_GET['errorMessage'])){
							echo '<div class="sign_in_error">';
							echo '<span>' . $_GET['errorMessage'] . '</span>';
							echo '</div>';
						}
			?>
			<p class="specific">Ecco i dati del tuo account</p>
			<?php
				global $EventCrateDb;
				$username = $_SESSION['username'];
				$queryText = "select * from dati_registrazione where username = '" . $username . "'";
				$result = $EventCrateDb->performQuery($queryText);
				$num = mysqli_num_rows($result);
				if ($num <= 0){
					echo '<p>Si � verificato un errore durante il caricamento dei dati</p>';
				}
				if ($num > 0){
					while($Row = $result->fetch_assoc()){
						if ($Row['regione'] == 'Emilia_romagna'){
							$Row['regione'] = "Emilia Romagna";
						}
						if ($Row['regione'] == 'Friuli_venezia_giulia'){
							$Row['regione'] = "Friuli Venezia Giulia";
						}
						if ($Row['regione'] == 'Trentino_alto_adige'){
							$Row['regione'] = "Trentino Alto Adige";
						}
						if ($Row['regione'] == 'Valle_d_aosta'){
							$Row['regione'] = "Valle d' Aosta";
						}
						echo '<div class="info_line"><p class="profile_info_tag">Username: </p><p class="profile_info">' . $Row['username'] . '</p></div>';
						echo '<div class="info_line"><p class="profile_info_tag">Email: </p><p class="profile_info">' . $Row['email'] . '</p></div>';
						echo '<div class="info_line"><p class="profile_info_tag">Nome: </p><p class="profile_info">' . $Row['nome'] . '</p></div>';
						echo '<div class="info_line"><p class="profile_info_tag">Cognome: </p><p class="profile_info">' . $Row['cognome'] . '</p></div>';
						if ($Row['data_nascita'] == '0000-00-00'){
							echo '<div class="info_line"><p class="profile_info_tag">Data di nascita: </p><p class="profile_info"> Non specificata</p></div>';
						}
						else {
							echo '<div class="info_line"><p class="profile_info_tag">Data di nascita: </p><p class="profile_info">' . $Row['data_nascita'] . '</p></div>';
						}
						if ($Row['regione'] == 'all'){
							echo '<div class="info_line"><p class="profile_info_tag">Regione: </p><p class="profile_info"> Non specificata</p></div>';
						}
						else {
							echo '<div class="info_line"><p class="profile_info_tag">Regione: </p><p class="profile_info">' . $Row['regione'] . '</p></div>';
						}
						if ($Row['citta'] == NULL){
							echo '<div class="info_line"><p class="profile_info_tag">Citta: </p><p class="profile_info"> Non specificata</p></div>';
						}
						else {
							echo '<div class="info_line"><p class="profile_info_tag">Citta: </p><p class="profile_info">' . $Row['citta'] . '</p></div>';
						}
						
					}
				}
			?>
			<p class="help_text">E' possibile modificare alcuni dati del proprio account, clicca <a href="./modify.php" class="help_link">qui</a> per aggiornarli.</p>
		</div>
		
	</body>
</html>