<!DOCTYPE=html>
<?php
	session_start();
    include "./utility/eventcrate_db_session.php";
    if (!isLogged()){
		    header('Location: ./sign_in.php');
		    exit;
    }
?>
<html lang="it">
		<head>
		<style>
		@import url('https://fonts.googleapis.com/css?family=Fredoka+One');
		@import url('https://fonts.googleapis.com/css?family=M+PLUS+Rounded+1c');
		</style>
		<meta charset="utf-8"> 
		<meta name = "author" content = "Leonardo">
		<meta name = "keywords" content = "eventcrate, events, event planner, online planner, event manager, registration">
		<meta name = "description" content = "Crea, organizza o partecipa agli eventi direttamente tramite la nostra piattaforma online">
		<link rel="stylesheet" href="./../css/registration.css" type="text/css" media="screen">
		<script type="text/javascript" src="./../js/registration.js"></script>
		<title>EventCrate - Modifica dati dell' account</title>
	</head>
	<body>
		<div class="top_h1">
		<a href="./home.php"><img class="back-arrow" src="./../css/img/left-arrow.png" alt="indietro"></a>
		<h1>Modifica dati</h1>
		</div>
		<div class="registration_box">
			<div class="login_box">
				<form id="reg_form" action="./scripts/modify_optional.php" method="post">
					<?php
						if (isset($_GET['errorMessage'])){
							echo '<div class="sign_in_error">';
							echo '<span>' . $_GET['errorMessage'] . '</span>';
							echo '</div>';
						}
					?>
					<p class="specific">Modifica dati opzionali<p><br>
					<input type="date" name="birthdate" id="date_new"><br>
					<select name="region">
						<option value="all">Regione</option>
						<option value="Abruzzo">Abruzzo</option>
						<option value="Basilicata">Basilicata</option>
						<option value="Calabria">Calabria</option>
						<option value="Campania">Campania</option>
						<option value="Emilia_romagna">Emilia Romagna</option>
						<option value="Friuli_venezia_giulia">Friuli Venezia Giulia</option>
						<option value="Lazio">Lazio</option>
						<option value="Liguria">Liguria</option>
						<option value="Lombardia">Lombardia</option>
						<option value="Marche">Marche</option>
						<option value="Molise">Molise</option>
						<option value="Piemonte">Piemonte</option>
						<option value="Puglia">Puglia</option>
						<option value="Sardegna">Sardegna</option>
						<option value="Sicilia">Sicilia</option>
						<option value="Toscana">Toscana</option>
						<option value="Trentino_alto_adige">Trentino Alto Adige</option>
						<option value="Umbria">Umbria</option>
						<option value="Valle_d_aosta">Valle d'Aosta</option>
						<option value="Veneto">Veneto</option>
					</select><br>
					<input type="text" name="city" placeholder="Citta"><br>
					<input type="submit" class="sub_b" value="Invia">
				</form>
			</div>
		</div>
		<div class="registration_box">
			<div class="login_box">
				<form id="reg_form" action="./scripts/modify_password.php" method="post">
					<?php
						if (isset($_GET['errorMessage'])){
							echo '<div class="sign_in_error">';
							echo '<span>' . $_GET['errorMessage'] . '</span>';
							echo '</div>';
						}
					?>
					<p class="specific">Modifica password<p><br>
					<input type="password"name="old_password" placeholder="Vecchia password"><br>
					<input type="password" name="new_password" placeholder="Nuova password"><br>
					<input type="password" name="new_password_rep" placeholder="Ripeti la nuova password"><br>
					<input type="submit" class="sub_b" value="Invia">
				</form>
			</div>
		</div>
		
	</body>
</html>