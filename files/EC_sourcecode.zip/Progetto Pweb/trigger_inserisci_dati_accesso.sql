
drop trigger if exists inserisci_dati_accesso;

delimiter $$


create trigger inserisci_dati_accesso
after insert on dati_registrazione
for each row
	begin
		declare _user varchar(25);
		declare _pass varchar(25);
		declare _regione varchar(25);
		declare _citta varchar(25);

		select d.username, d.password, d.regione, d.citta into _user, _pass, _regione, _citta
		from dati_registrazione d
		where d.username = new.username;

		insert into utente
		values(_username,_password,NULL,_regione,_citta);
	end$$
    
delimiter;