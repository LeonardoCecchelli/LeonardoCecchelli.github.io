#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define MAX_BUFFER_SIZE 1024
#define MAX_FILENAME_SIZE 1024
#define MAX_MODE_SIZE 8

int main(int argc, char* argv[]){

	//Controllo parametri di configurazione
	if(argc != 3){
		printf("\n Parametri per la configurazione del server non validi \n");
		return 0;
	}

	pid_t pid;
	int ret, sd;

	int port = atoi(argv[1]); //Porta
	char directory_path[sizeof(argv[2])]; //Percorso directory da cui prelevare i files
	strcpy(directory_path,argv[2]);

	printf(" \n Avvio server \n  porta: %d \n  directory specificata: %s \n",port,directory_path);

	printf(" \n Creazione del socket in corso... \n");

	char *slash=(char*)"/";
	strncat(directory_path,slash,sizeof(directory_path)+1);

	struct sockaddr_in my_addr, client_addr;
	socklen_t addrlen = sizeof(client_addr);

  sd = socket(AF_INET,SOCK_DGRAM,0); // Creazione socket bloccante

	memset(&my_addr, 0, sizeof(my_addr)); // Creazione indirizzo di bind
  my_addr.sin_family = AF_INET;
  my_addr.sin_port = htons(port);
  my_addr.sin_addr.s_addr = INADDR_ANY;

  ret = bind(sd, (struct sockaddr*)&my_addr, sizeof(my_addr));

	if (ret < 0){ //Errore nella creazione del socket
		printf("\n Creazione socket non riuscita \n");
		perror("\n Errore: ");
		exit(1);
	}
	printf(" \n Creazione socket completata. \n \n Attesa richieste di connessione... \n");
	printf("\n");

	char buf[MAX_BUFFER_SIZE];

	while(1){
		ret = recvfrom(sd, buf, MAX_BUFFER_SIZE, 0,(struct sockaddr*)&client_addr, &addrlen); // Attendo richieste di connessione

		if (ret == -1) {
			printf("\n Errore nel messaggio ricevuto \n");
			continue;
		}
		if (ret == 0){
			printf("\n Socket remoto chiuso \n");
			continue;
		}

		pid = fork();

		if (pid == -1){ //Errore nella creazione del processo
			printf("\n Errore nella creazione del processo \n");
			exit(1);
		}
		if (pid == 0){ //Processo figlio per il trasferimento dati
			int len_son, ret_son;
			int sd_son = socket(AF_INET,SOCK_DGRAM,0);
			struct sockaddr_in c_addr;

			memcpy((struct sockaddr*)&c_addr, (struct sockaddr*)&client_addr, sizeof(client_addr));
			socklen_t a_len = sizeof(c_addr);

			memset(&my_addr, 0, sizeof(my_addr));
			my_addr.sin_family = AF_INET;
			my_addr.sin_port = htons(0);
			my_addr.sin_addr.s_addr = INADDR_ANY;

			ret_son = bind(sd_son, (struct sockaddr*)&my_addr, sizeof(my_addr));

			if(ret_son < 0){
				printf("\n Creazione socket processo dati non riuscita \n");
				perror(" Errore: ");
				exit(1);
			}

			char buf_son[MAX_BUFFER_SIZE];
			uint16_t op_code;
			char filename [MAX_FILENAME_SIZE];
			char mode [MAX_MODE_SIZE];

			memcpy(buf_son,buf,sizeof(buf));

			//Deserializzazione del messaggio di richiesta
			int index = 0;
			memcpy(&op_code,&buf_son+index,sizeof(op_code));
			op_code = ntohs(op_code);
			index = index + sizeof(op_code);
			strcpy(filename, buf_son+index);
			index = index + strlen(filename) + 1;
			strcpy(mode, buf_son+index);
			index = index + strlen(mode) + 1;

			//Gestione errore illegal TFTP operation
			if (op_code != 1){
				int i = 0;
				uint16_t op_code_err = htons(5);
				uint16_t error_number = htons(4);

				//Serializzazione del messaggio di errore
				memcpy(buf_son+i, &op_code_err, sizeof(op_code_err));
				i = i + sizeof(op_code_err);
				memcpy(buf_son+i, &error_number, sizeof(error_number));
				i = i + sizeof(error_number);
				strcpy(buf_son+i, "Illegal TFTP operation.\0");
				i = i + strlen("Illegal TFTP operation.\0") + 1;

				//Invio messaggio di errore
				len_son = sendto(sd_son, buf_son, i, 0,(struct sockaddr*)&c_addr, sizeof(c_addr));
				if (len_son < 0){
					printf(" Impossibile inviare il messaggio di errore \n");
					printf("\n");
				}
				else {
						printf(" Messaggio di errore inviato: Illegal TFTP operation. \n");
						printf("\n");
				}
				close(sd_son);
				exit(1);
			}

			int filepath_dim = sizeof(directory_path) + sizeof(filename);
			strncat(directory_path,filename,filepath_dim);
			FILE *fpointer;
			char *m;
			if (!strcmp(mode,"netascii")){
				m = (char*)"r";
			}
			else {
				m = (char*)"rb";
			}
			fpointer = fopen(directory_path,m);
			if (fpointer == NULL){ // Gestione errore file not found
				int i = 0;
				uint16_t op_code_err = htons(5);
				uint16_t error_number = htons(1);

				//Serializzazione del messaggio di errore
				memcpy(buf_son+i, &op_code_err, sizeof(op_code_err));
				i = i + sizeof(op_code_err);
				memcpy(buf_son+i, &error_number, sizeof(error_number));
				i = i + sizeof(error_number);
				strcpy(buf_son+i, "File not found.\0");
				i = i + strlen("File not found.\0") + 1;

				//Invio messaggio di errore
				len_son = sendto(sd_son, buf_son, i, 0,(struct sockaddr*)&c_addr, sizeof(c_addr));
				if (len_son < 0){
					printf(" Impossibile inviare il messaggio di errore \n");
					printf("\n");
				}
				else {
					printf(" Messaggio di errore inviato: File not found. \n");
					printf("\n");
				}
				close(sd_son);
				fclose(fpointer);
				exit(1);
			}

			//Casi di errori gestiti, inizio trasferimento dei dati
			uint16_t b_num = 1;
			uint16_t block_number = htons(1);
			uint16_t op_code_data = htons(3);
			char data_buf[512];
			int data_len;

			while(1) {
				data_len = fread(data_buf,1,sizeof(data_buf),fpointer);

				//Serializzazione del messaggio data
				int i = 0;
				memcpy(buf_son+i, &op_code_data, sizeof(op_code_data));
				i = i + sizeof(op_code_data);
				memcpy(buf_son+i, &block_number, sizeof(block_number));
				i = i + sizeof(block_number);
				memcpy(buf_son+i, &data_buf, data_len);
				i = i + data_len;

				//Invio del messaggio data
				len_son = sendto(sd_son, buf_son, i, 0,(struct sockaddr*)&c_addr, sizeof(c_addr));
				if (len_son < 0){
					printf("\n Impossibile inviare pacchetto dati \n");
					fclose(fpointer);
					exit(1);
				}
				else {
					printf(" Pacchetto dati inviato, numero blocco: %d dimensione dati: %d  \n",b_num,data_len);
				}

				//Attesa del messaggio ACK
				ret_son = recvfrom(sd_son, buf_son, MAX_BUFFER_SIZE, 0,(struct sockaddr*)&c_addr, &a_len);
				if (ret_son == -1) {
					printf("\n Errore nel messaggio ricevuto \n");
					fclose(fpointer);
					close(sd_son);
					exit(1);
				}
				if (ret_son == 0){
					printf("\n Socket remoto chiuso \n");
					fclose(fpointer);
					close(sd_son);
					exit(1);
				}

				//Deserializzazione messaggio ACK
				i = 0;
				memcpy(&op_code_data,buf_son+i,sizeof(op_code_data));
				op_code_data = ntohs(op_code_data);
				i = i + sizeof(op_code_data);
				memcpy(&block_number,buf_son+i,sizeof(block_number));
				block_number = ntohs(block_number);
				i = i + sizeof(block_number);

				if (block_number != b_num){ //Controllo block_number ricevuto nel messaggio di ACK
					printf(" Block number errato \n");
				}
				else {
					printf(" Messaggio di ACK ricevuto, block number : %d \n",block_number);
				}

				//Controllo se ho inviato tutto il file
				if (data_len < 512){
					printf("\n Invio del file completato \n");
					printf("\n");
					fclose(fpointer);
					break;
				}

				//Incremento contatore dei blocchi
				++b_num;
				++block_number;
				block_number = htons(block_number);
			}
			close(sd_son);
			exit(1);
		}
	}
	return 0;
}
