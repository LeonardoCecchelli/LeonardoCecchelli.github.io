#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define MAX_BUFFER_SIZE 1024
#define MAX_FILENAME_SIZE 1024
#define MAX_MODE_SIZE 8
#define MAX_ERROR_MESSAGE 30

int main(int argc, char* argv[]){
  //Controllo parametri di configurazione
  if(argc != 3){
    printf("\n Parametri per la configurazione del client non validi \n");
    return 0;
  }

  int ret, sd_c;
  int s_port = atoi(argv[2]);
  char s_ip [sizeof(argv[1])];
  strcpy(s_ip,argv[1]);

//  printf("\n Avvio client, indirizzo server: %s : %d  \n",s_ip,s_port); debug

  struct sockaddr_in s_addr;
  sd_c = socket(AF_INET, SOCK_DGRAM, 0);
  memset(&s_addr, 0, sizeof(s_addr));
  s_addr.sin_family = AF_INET ;
  s_addr.sin_port = htons(s_port);
  inet_pton(AF_INET, s_ip, &s_addr.sin_addr);

  printf(" \nSono disponibili i seguenti comandi: \n");
  printf(" \n !help --> mostra l'elenco dei comandi disponibili \n");
  printf(" \n !mode {txt|bin} --> imposta il modo di trasferimento dei files (testo o binario) \n");
  printf(" \n !get filename nome_locale --> richiede al server il nome del file <filename> e lo salva localmente con il nome <nome_locale> \n");
  printf(" \n !quit --> termina il client \n");

  char cmd [5];
  char mode [MAX_MODE_SIZE];
  char buf_c [MAX_BUFFER_SIZE];

  strcpy(mode,"octect"); // modalità bin di default

  while (1) {
    printf("\n> ");
    scanf("%s",cmd);

    if (!strcmp(cmd,"!help")){ // Comando di help
      printf("\nSono disponibili i seguenti comandi: \n");
      printf(" \n !help --> mostra l'elenco dei comandi disponibili \n");
      printf(" \n !mode {txt|bin} --> imposta il modo di trasferimento dei files (testo o binario) \n");
      printf(" \n !get filename nome_locale --> richiede al server il nome del file <filename> e lo salva localmente con il nome <nome_locale> \n");
      printf(" \n !quit --> termina il client \n");
      continue;
    }

    if (!strcmp(cmd,"!quit")){
      close(sd_c);
      return 0;
    }

    if (!strcmp(cmd,"!mode")){ // Comando di mode
      char m [4];
      scanf("%s",m);
      if (!strcmp(m,"txt")){
        strcpy(mode,"netascii");
        printf("\n Modo di trasferimento testuale configurato \n");
        continue;
      }
      else if (!strcmp(m,"bin")){
        strcpy(mode,"octect");
        printf("\n Modo di trasferimento binario configurato \n");
        continue;
      }
      else {
        printf("\n Parametro modalità trasferimento non valido \n");
        continue;
      }
    }

    if (!strcmp(cmd,"!get")) { // Comando di get
      uint16_t op_code;
      uint16_t block_number;
      int index = 0;
      char f_name [MAX_FILENAME_SIZE];
      char local_name [MAX_FILENAME_SIZE];
      char data_block [512];
      int dim_block;
      uint16_t recv_blocks = 0;
      char *m_s;

      struct sockaddr_in s_addr_data;
      socklen_t addr_l =  sizeof(s_addr_data);

      scanf("%s",f_name);
      scanf("%s",local_name);

      if (!strcmp(mode,"netascii")){
        m_s = (char*)"w";
      }
      else {
        m_s = (char*)"wb";
      }

      FILE *fpointer; // Apertura file
      fpointer = fopen(local_name,m_s);

      op_code = htons(1); // Operazione RRQ

      //Serializzazione messaggio di richiesta
      index = 0;
      memcpy(buf_c + index,&op_code,sizeof(op_code));
      index = index + sizeof(op_code);
      strcpy(buf_c+index,f_name);
      index = index + strlen(f_name) + 1;
      strcpy(buf_c+index,mode);
      index = index + strlen(mode) + 1;

      //Invio messaggio di richiesta
      ret = sendto(sd_c, buf_c, index, 0, (struct sockaddr*)&s_addr, sizeof(s_addr));

      if (ret < 0){
        printf("\n Impossibile inviare messaggio di richiesta al server \n");
        close(sd_c);
        fclose(fpointer);
        return 0;
      }
      printf("\nRichiesta file %s al server in corso \n",f_name);
      printf("Trasferimento file in corso \n");
      while(1){
        //Attendo messaggio data
        ret = recvfrom(sd_c, buf_c, MAX_BUFFER_SIZE, 0, (struct sockaddr*)&s_addr_data, &addr_l);

        //Deserializzazione messaggio risposta
        index = 0;

        memcpy(&op_code,buf_c+index,sizeof(op_code));
        op_code = ntohs(op_code);
        index = index + sizeof(op_code);

        if (op_code == 5){ // Messaggio di errore
            char error_message [MAX_ERROR_MESSAGE];
            uint16_t error_number;
            memcpy(&error_number,buf_c+index,sizeof(error_number));
            index = index + sizeof(error_number);
            strcpy(error_message, buf_c+index);
            index = index + strlen(error_message) + 1;

            printf("Si è verificato un errore durante il trasferimento del file \n");
            printf("Error message: %s \n",error_message);
            fclose(fpointer);
            break;
        }

        //Deserializzazione blocco dati
        memcpy(&block_number,buf_c+index,sizeof(block_number));
        index = index + sizeof(block_number);
        dim_block = ret - index;
        memcpy(&data_block,buf_c+index,dim_block);
        index = index + dim_block;

        //Copio dati nel file
        fwrite(data_block,1,dim_block,fpointer);

        //Serializzazione messaggio ACK
        index = 0;
        op_code = htons(4);
        memcpy(buf_c + index,&op_code,sizeof(op_code));
        index = index + sizeof(op_code);
        memcpy(buf_c + index,&block_number,sizeof(op_code));
        index = index + sizeof(block_number);
        recv_blocks++;

        //Invio messaggio ACK
        ret = sendto(sd_c, buf_c, index, 0, (struct sockaddr*)&s_addr_data, sizeof(s_addr_data));

        if (ret < 0){
          printf("\n Impossibile inviare messaggio di ACK al server \n");
          close(sd_c);
          fclose(fpointer);
          return 0;
        }

        if (dim_block < 512){ //Ultimo blocco dati
          block_number = ntohs(block_number);
          printf("Trasferimento file completato (%d/%d blocchi) \n",recv_blocks,block_number);
          fclose(fpointer);
          printf("Salvataggio ./%s completato \n",local_name);
          break;
        }
      }
    }
  }
  return 0;
}
